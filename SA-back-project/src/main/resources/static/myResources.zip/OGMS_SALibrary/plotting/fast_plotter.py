import matplotlib.pyplot as plt
import numpy as np


def bar(Si, plot=True, path="", target=""):
    labels = Si['names']
    x = np.arange(len(labels))  # the label locations
    width = 0.2  # the width of the bars
    fig, ax = plt.subplots()
    for key in Si:
        if key == 'S1':
            ax.bar(x-width/2, Si[key], width, label="S1")
        elif key == 'Vi':
            ax.bar(x+width/2, Si[key], width, label="Vi")

    ax.set_title('Sensitivity Index of FAST')
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.legend()

    fig.tight_layout()

    plt.savefig(path + 'SA_score_figure_' + target + '.jpg')
    if plot:
        plt.show()
